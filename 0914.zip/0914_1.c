#include<stdio.h>

int main(void) {
	printf("first programming\n");
	printf("first programming\n");
	printf("first programming\n");
	printf("first programming\n");

	return 0;
}